"use strict";

module.exports = (app) => {
    app.use("/api/users", require("../controller/user"));
    app.use("/api/teacher", require("../controller/teacher"));
    app.use("/api/student", require("../controller/student"));
    app.use("/api/course", require("../controller/course"));

    // app.use("/", function(req, res, next) {
    //     res.send('<h4 style="text-align:center">Index Route.</h4>');
    // });

    // app.use((err, req, res, next) => {
    //     if (err.name === "UnauthorizedError") {
    //         res.status(err.status).send({
    //             message: "Your authentication information is incorrect. Please try again.",
    //             api_msg: err.message,
    //             code: 999,
    //         });
    //         log.error(err);
    //         return;
    //     }
    //     next();
    // });
};