const teacher = require("./models/teacher");
const { v4: uuidv4 } = require("uuid");
const moment = require("moment");
exports.index = (req, res) => {
    teacher.find({}, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "teacher gets failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "teacher gets successfully",
                statusCode: 200,
            });
        }
    });
};

exports.show = (req, res) => {
    if (!req.params.teacherId) {
        return res.send("teacher Id missing");
    }
    teacher.findOne({ Id: req.params.teacherId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "teacher gets failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "teacher gets successfully",
                statusCode: 200,
            });
        }
    });
};
exports.update = (req, res) => {
    if (!req.params.teacherId) {
        return res.send("teacher Id missing");
    }
    let updateteachers = {};
    updateteachers.first_name = req.body.first_name;
    updateteachers.last_name = req.body.last_name;
    updateteachers.joining_date = req.body.joining_date ?
        req.body.joining_date :
        moment().format("DD-MM-YYYY");
    updateteachers.experience = req.body.experience ?
        req.body.experience :
        moment().add(1, "M").format("DD-MM-YYYY");
    let courseList = { $push: { courseList: [course] } };
    Object.assign(updateteachers, courseList);
    teacher.findOneAndUpdate({ Id: req.params.teacherId }, { $set: updateteachers }, { upsert: true, new: true },
        (err, data) => {
            if (err) {
                res.send({
                    statusCode: 400,
                    msg: "teacher data updated failed",
                    data: err,
                });
            } else {
                res.send({
                    statusCode: 200,
                    msg: "teacher data updated successfully",
                    data: data,
                });
            }
        }
    );
};
exports.addTeacher = (req, res, next) => {
    let joining_date = req.body.joining_date ?
        req.body.joining_date :
        moment().format("DD-MM-YYYY");
    let courses = req.body.course;
    let courseList = {
        $push: {
            courseList: {
                $each: courses,
            },
        },
    };
    let couseID = uuidv4();
    const teacherInfo = new teacher({
        Id: couseID,
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        joining_date: joining_date,
        experience: req.body.experience,
        courseList: courses,
    });
    teacherInfo.save((err, data) => {
        if (err) {
            res.send({
                statusCode: 400,
                data: err,
                msg: "New teacher inserted failed",
            });
        } else {
            res.send({
                statusCode: 200,
                data: teacher,
                msg: "New teacher inserted successfully",
            });
        }
    });
};
exports.delete = (req, res) => {
    if (!req.params.teacherId) {
        return res.send("teacher Id missing");
    }
    teacher.deleteOne({ Id: req.params.teacherId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "teacher deleted failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "teacher deleted successfully",
                statusCode: 200,
            });
        }
    });
};