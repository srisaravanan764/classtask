var mongoose = require("mongoose");
var Schema = mongoose.Schema;

(teacherSchema = new Schema({
    Id: String,
    first_name: String,
    last_name: String,
    experience: Number,
    courseList: [],
    email: String,
    joining_date: {
        type: Date,
        default: new Date(),
    },
    updated_at: {
        type: Date,
        default: new Date(),
    },
})),
(teacher = mongoose.model("Teacher", teacherSchema));

module.exports = teacher;