var mongoose = require("mongoose");
var Schema = mongoose.Schema;

(studentSchema = new Schema({
    Id: String,
    first_name: String,
    last_name: String,
    courseList: [],
    email: String,
    joining_date: {
        type: Date,
        default: new Date(),
    },
    updated_at: {
        type: Date,
        default: new Date(),
    },
})),
(student = mongoose.model("student", studentSchema));

module.exports = student;