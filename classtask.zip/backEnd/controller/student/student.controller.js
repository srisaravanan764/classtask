const student = require("./models/student");
const { v4: uuidv4 } = require("uuid");
const moment = require("moment");
exports.index = (req, res) => {
    student.find({}, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "student gets failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "student gets successfully",
                statusCode: 200,
            });
        }
    });
};

exports.show = (req, res) => {
    if (!req.params.studentId) {
        return res.send("student Id missing");
    }
    student.findOne({ Id: req.params.studentId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "student gets failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "student gets successfully",
                statusCode: 200,
            });
        }
    });
};
exports.update = (req, res) => {
    if (!req.params.studentId) {
        return res.send("student Id missing");
    }
    let updatestudents = {};
    updatestudents.first_name = req.body.first_name;
    updatestudents.last_name = req.body.last_name;
    updatestudents.joining_date = req.body.joining_date ?
        req.body.joining_date :
        moment().format("DD-MM-YYYY");
    updatestudents.experience = req.body.experience ?
        req.body.experience :
        moment().add(1, "M").format("DD-MM-YYYY");
    let courseList = { $push: { courseList: [course] } };
    Object.assign(updatestudents, courseList);
    student.findOneAndUpdate({ Id: req.params.studentId }, { $set: updatestudents }, { upsert: true, new: true },
        (err, data) => {
            if (err) {
                res.send({
                    statusCode: 400,
                    msg: "student data updated failed",
                    data: err,
                });
            } else {
                res.send({
                    statusCode: 200,
                    msg: "student data updated successfully",
                    data: data,
                });
            }
        }
    );
};

exports.addStudent = (req, res, next) => {
    let joining_date = req.body.joining_date ?
        req.body.joining_date :
        moment().format("DD-MM-YYYY");
    let courses = req.body.course;
    let Id = uuidv4();
    const studentInfo = new student({
        Id: Id,
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        joining_date: joining_date,
        courseList: courses,
    });
    studentInfo.save((err, student) => {
        if (err) {
            res.send({
                statusCode: 400,
                data: err,
                msg: "New student inserted failed",
            });
        } else {
            res.send({
                statusCode: 200,
                data: student,
                msg: "New student inserted successfully",
            });
        }
    });
};
exports.delete = (req, res) => {
    if (!req.params.studentId) {
        return res.send("student Id missing");
    }
    student.deleteOne({ Id: req.params.studentId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "student deleted failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "student deleted successfully",
                statusCode: 200,
            });
        }
    });
};