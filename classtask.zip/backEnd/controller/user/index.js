"use strict";

const express = require("express");
const controller = require("./user.controller");
const getRole = require("./getRole");

const router = express.Router();
router.get("/:courseId", controller.getDataById);
router.post("/get_all", getRole, controller.index);
router.post("/register", controller.creatUser);
router.put("/:id", controller.update);
router.post("/login", getRole, controller.login);
router.get("/logout", controller.logout);
router.post("/changePwd", getRole, controller.changePassword);
router.post("/forgot", getRole, controller.forgotPassword);
router.delete("/:id", controller.deleteUser);

module.exports = router;