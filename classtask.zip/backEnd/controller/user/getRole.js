const jwt = require("jsonwebtoken");
const User = require("./models/user");
const role = (req, res, next) => {
    try {
        let authToken = req.headers.authorization;
        const { email, role } = req.body;
        if (!email) {
            return res.status(400).json({ response: err, msg: "role is not defined please contact admin", statusCode: 400 })
        }
        return new Promise((resolve, reject) => {
            const UserRole = User.findOne({ email: { $regex: email, $options: 'i' } }, { name: 1, unique_id: 1, role: 1 },
                (err, data) => {
                    if (err) {
                        reject({ msg: "role authentication failed", statusCode: 400 })
                    } else {
                        resolve({ msg: "role authentication failed", data: data, statusCode: 200 })
                    }
                }
            );
            UserRole.then(data => {
                //jwt.verify(authToken, { id: data.unique_id, name: data.name })
                req.session.role = data.role ? data.role : role;
                req.session._id = data._id;
                next();
            }).catch(err => {
                res
                    .status(400)
                    .send(err);
            })
        })
    } catch (err) {
        return res.status(400).json({ response: err, msg: "role is not defined please contact admin", statusCode: 400 })
    }
};

module.exports = role;