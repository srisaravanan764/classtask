const User = require("./models/user");
const teacher = require("../teacher/models/teacher");
const student = require("../student/models/student");
const course = require("../course/models/course");
const { v4: uuidv4 } = require("uuid");
const moment = require("moment");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const validateRegisterInput = require("../../validation/register");
const validateLoginInput = require("../../validation/login");

exports.creatUser = (req, res, next) => {
    var personInfo = req.body;
    try {
        if (personInfo.password == personInfo.password2) {
            User.findOne({ email: personInfo.email }, (err, data) => {
                if (!data) {
                    var c;
                    User.findOne({}, (err, data) => {
                            if (data) {
                                console.log("if");
                                c = data.unique_id + 1;
                            } else {
                                c = 1;
                            }
                            // bcrypt.genSalt(10, (err, salt) => {
                            //     bcrypt.hash(personInfo.password, salt, (err, hash) => {
                            //         if (err) throw err;
                            //         personInfo.password = hash;
                            //     });
                            // });
                            var newPerson = new User({
                                unique_id: c,
                                email: personInfo.email,
                                username: personInfo.email,
                                password: personInfo.password,
                                passwordConf: personInfo.password2,
                                role: personInfo.role,
                                name: `${personInfo.name} ${personInfo.lname}`,
                            });

                            newPerson.save(async(err, Person) => {
                                if (err) console.log(err);
                                else {
                                    console.log("success");
                                    try {
                                        await classData(personInfo);
                                    } catch (err) {
                                        console.error(err);
                                    }
                                }
                            });
                        })
                        .sort({ _id: -1 })
                        .limit(1);

                    res.status(200).json({
                        Success: "You are registered,You can login now.",
                        statusCode: 200,
                    });
                } else {
                    res
                        .status(500)
                        .json({ Success: "Email is already used.", statusCode: 500 });
                }
            });
        } else {
            res
                .status(400)
                .json({ statusCode: 400, password_mismatch: "Password incorrect" });
        }
    } catch (err) {
        res
            .status(400)
            .json({ statusCode: 400, err: err, msg: "User creation failed", password_mismatch: "Password incorrect" });
    }
};
const classData = (personInfo) => {
    return new Promise((resolve, reject) => {
        try {
            let joining_date = personInfo.joining_date ?
                personInfo.joining_date :
                moment().format("DD-MM-YYYY");
            let info = {
                Id: uuidv4(),
                first_name: personInfo.name,
                last_name: personInfo.lname,
                joining_date: joining_date,
                courseList: personInfo.course,
                email: personInfo.email,
            };
            let roleInfo = personInfo.role == "teacher" ? "teacher" : "student";
            if (personInfo.role.trim() == "teacher") {
                info = new teacher(
                    Object.assign(info, {
                        experience: personInfo.experience,
                    })
                );
            } else if (personInfo.role.trim() == "student") {
                info = new student(info);
            } else {
                reject("role is mismatching");
            }
            info.save((err, data) => {
                if (err) {
                    reject({
                        statusCode: 400,
                        data: err,
                        msg: `New ${roleInfo} inserted failed`,
                    });
                } else {
                    resolve({
                        statusCode: 200,
                        data: data,
                        msg: `New ${roleInfo} inserted successfully`,
                    });
                }
            });
        } catch (err) {
            reject({
                statusCode: 400,
                data: err,
                msg: `New ${roleInfo} inserted failed`,
            });
        }
    });
};
exports.login = (req, res, next) => {
    try {
        req.session.secret = "Bz-338MXCVgoBePrjWeYRZDIdeHgvlz-";
        let keys = "Bz-338MXCVgoBePrjWeYRZDIdeHgvlz-";
        User.findOne({ email: req.body.email }, (err, data) => {
            if (err) {
                res.status(401).json({ statusCode: 401, msg: "Invalid credentials" });
            }
            if (data) {
                if (data.password == req.body.password) {
                    req.session.userId = data.unique_id;
                    const payload = {
                        id: data.unique_id,
                        name: data.name,
                    };
                    // Sign token
                    jwt.sign(
                        payload,
                        keys, {
                            expiresIn: 31556926, // 1 year in seconds
                        },
                        (err, token) => {
                            if (err) {
                                res.status(400).json({
                                    response: err,
                                    msg: "Login failed",
                                    statusCode: 400,
                                });
                            }
                            res.status(200).json({
                                success: true,
                                data: { names: data.name, email: data.unique_id, username: data.email },
                                role: data.role,
                                email: data.email,
                                msg: "Login successfully",
                                statusCode: 200,
                                token: "Bearer " + token,
                            });
                        }
                    );
                } else {
                    res.status(400).json({ response: "", msg: "Wrong password!", statusCode: 400 });
                }
            } else {
                res
                    .status(500)
                    .json({ msg: "This Email Is not registered!", statusCode: 500 });
            }
        });
    } catch (err) {
        res
            .status(500)
            .json({ msg: "Invalid credentials please contach admin", err: err, statusCode: 500 });
    }
};

exports.logout = (req, res, next) => {
    console.log("logout");
    if (req.session) {
        req.session.destroy(function(err) {
            if (err) {
                return next(err);
            } else {
                return res.redirect("/");
            }
        });
    }
};

exports.forgotPassword = (req, res, next) => {
    User.findOne({ email: req.body.email }, function(err, data) {
        console.log(data);
        if (!data) {
            res.send({ Success: "This Email Is not regestered!" });
        } else {
            // res.send({"Success":"Success!"});
            if (req.body.password == req.body.passwordConf) {
                data.password = req.body.password;
                data.passwordConf = req.body.passwordConf;

                data.save(function(err, Person) {
                    if (err) console.log(err);
                    else console.log("Success");
                    res.send({ Success: "Password changed!" });
                });
            } else {
                res.send({
                    Success: "Password does not matched! Both Password should be same.",
                });
            }
        }
    });
};
exports.changePassword = (req, res, next) => {
    User.findOne({ email: req.body.email }, function(err, data) {
        console.log(data);
        if (!data) {
            res.send({ Success: "This Email Is not regestered!" });
        } else {
            // res.send({"Success":"Success!"});
            if (req.body.password == req.body.passwordConf) {
                data.password = req.body.password;
                data.passwordConf = req.body.passwordConf;

                data.save(function(err, Person) {
                    if (err) console.log(err);
                    else console.log("Success");
                    res.send({ Success: "Password changed!" });
                });
            } else {
                res.send({
                    Success: "Password does not matched! Both Password should be same.",
                });
            }
        }
    });
};
exports.index = (req, res) => {
    let role = req.session.role ? req.session.role.trim() : "teacher";
    let schema = role == "student" ? student : teacher;
    let msg = role == "student" ? "student" : "teacher";
    let schemaCond = new Object();
    if (req.params.id && role == "student") {
        schemaCond.Id = req.params.id;
    }
    Object.assign(schemaCond, {
        email: req.body.email ? req.body.email : req.body.username,
        "courseList.0": { $exists: true },
    });
    console.log("schemaCond", schemaCond, "schema", schema);
    schema.aggregate(
        [
            { $match: schemaCond },
            { $unwind: "$courseList" },
            {
                $lookup: {
                    from: "courses",
                    localField: "courseList",
                    foreignField: "couseID",
                    as: "course",
                },
            },
            {
                $project: {
                    Id: 1,
                    courseList: 1,
                    experience: 1,
                    courseData: "$course",
                },
            },
        ],
        (err, data) => {
            if (err) {
                return res.send({
                    data: err,
                    msg: `${msg} gets failed`,
                    statusCode: 401,
                });
            } else {
                return res.send({
                    data: data,
                    msg: `${msg} gets successfully`,
                    statusCode: 200,
                });
            }
        }
    );
};

exports.getDataById = (req, res) => {
    if (!req.params.courseId) {
        return res.send("Course Id missing");
    }
    let courseId = req.params.courseId ? req.params.courseId : "";
    student.find({ courseList: courseId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: `data gets failed`,
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: `data gets successfully`,
                statusCode: 200,
            });
        }
    });
};
exports.update = (req, res) => {
    if (!req.params.courseId) {
        return res.send("Id missing");
    }
    let updateCourses = {};
    updateCourses.Name = req.body.courseName;
    updateCourses.Description = req.body.courseDesc;
    updateCourses.start_date = req.body.start_date ?
        req.body.start_date :
        moment().format("DD-MM-YYYY");
    updateCourses.end_date = req.body.end_date ?
        req.body.end_date :
        moment().add(1, "M").format("DD-MM-YYYY");
    course.findOneAndUpdate({ couseID: req.params.courseId },
        updateCourses, { upsert: true, new: true },
        (err, data) => {
            if (err) {
                res.send({
                    statusCode: 400,
                    msg: "course data updated failed",
                    data: err,
                });
            } else {
                res.send({
                    statusCode: 200,
                    msg: "course data updated successfully",
                    data: data,
                });
            }
        }
    );
};
exports.addCourse = (req, res, next) => {
    let start_date = req.body.start_date ?
        req.body.start_date :
        moment().format("DD-MM-YYYY");
    let end_date = req.body.start_date ?
        req.body.end_date :
        moment().add(1, "M").format("DD-MM-YYYY");
    const courseInfo = new course({
        couseID: uuidv4(),
        Name: req.body.courseName,
        Description: req.body.courseDesc,
        start_date: start_date,
        end_date: end_date,
    });
    courseInfo.save((err, data) => {
        if (err) {
            res.send({
                statusCode: 400,
                data: err,
                msg: "New course inserted failed",
            });
        } else {
            res.send({
                statusCode: 400,
                data: data,
                msg: "New course inserted successfully",
            });
        }
    });
};
exports.deleteUser = (req, res) => {
    if (!req.params.courseId) {
        return res.send("Course Id missing");
    }
    course.deleteOne({ couseID: req.params.courseId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "course deleted failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "course deleted successfully",
                statusCode: 200,
            });
        }
    });
};