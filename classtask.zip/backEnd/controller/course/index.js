"use strict";
const express = require("express");
const controller = require("./course.controller");

const router = express.Router();
router.get("/", controller.index);
router.post("/", controller.addCourse);
router.get("/:courseId", controller.show);
router.put("/:courseId", controller.update);
router.delete("/:courseId", controller.delete);

module.exports = router;