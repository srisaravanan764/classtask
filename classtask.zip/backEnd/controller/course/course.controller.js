const course = require("./models/course");
const { v4: uuidv4 } = require("uuid");
const moment = require("moment");

exports.index = (req, res) => {
    course.find({}, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "course gets failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "course gets successfully",
                statusCode: 200,
            });
        }
    });
};

exports.show = (req, res) => {
    if (!req.params.courseId) {
        return res.send("Course Id missing");
    }
    course.findOne({ couseID: req.params.courseId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "course gets failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "course gets successfully",
                statusCode: 200,
            });
        }
    });
};
exports.update = (req, res) => {
    if (!req.params.courseId) {
        return res.send("Course Id missing");
    }
    let updateCourses = {};
    updateCourses.Name = req.body.courseName;
    updateCourses.Description = req.body.courseDesc;
    updateCourses.start_date = req.body.start_date ?
        req.body.start_date :
        moment().format("DD-MM-YYYY");
    updateCourses.end_date = req.body.end_date ?
        req.body.end_date :
        moment().add(1, "M").format("DD-MM-YYYY");
    course.findOneAndUpdate({ couseID: req.params.courseId },
        updateCourses, { upsert: true, new: true },
        (err, data) => {
            if (err) {
                res.send({
                    statusCode: 400,
                    msg: "course data updated failed",
                    data: err,
                });
            } else {
                res.send({
                    statusCode: 200,
                    msg: "course data updated successfully",
                    data: data,
                });
            }
        }
    );
};
exports.addCourse = (req, res, next) => {
    let start_date = req.body.start_date ?
        req.body.start_date :
        moment().format("DD-MM-YYYY");
    let end_date = req.body.start_date ?
        req.body.end_date :
        moment().add(1, "M").format("DD-MM-YYYY");
    const courseInfo = new course({
        couseID: uuidv4(),
        Name: req.body.courseName,
        Description: req.body.courseDesc,
        start_date: start_date,
        end_date: end_date,
    });
    courseInfo.save((err, data) => {
        if (err) {
            res.send({
                statusCode: 400,
                data: err,
                msg: "New course inserted failed",
            });
        } else {
            res.send({
                statusCode: 400,
                data: data,
                msg: "New course inserted successfully",
            });
        }
    });
};
exports.delete = (req, res) => {
    if (!req.params.courseId) {
        return res.send("Course Id missing");
    }
    course.deleteOne({ couseID: req.params.courseId }, (err, data) => {
        if (err) {
            return res.send({
                data: err,
                msg: "course deleted failed",
                statusCode: 401,
            });
        } else {
            return res.send({
                data: data,
                msg: "course deleted successfully",
                statusCode: 200,
            });
        }
    });
};