var mongoose = require("mongoose");
var Schema = mongoose.Schema;

(courseSchema = new Schema({
    couseID: String,
    Name: String,
    Description: String,
    start_date: {
        type: Date,
        default: new Date(),
    },
    end_date: {
        type: Date,
        default: new Date(),
    },
    updated_at: {
        type: Date,
        default: new Date(),
    },
})),
(course = mongoose.model("Course", courseSchema));

module.exports = course;