import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import Button from 'react-bootstrap/Button';
import { logoutUser , getAll,studentGetData,deleteData} from "../../actions/authActions";
class Dashboard extends Component {
	constructor(props){
		 super(props);
		this.state = {
			students : [],
			innerRow:false
		};
		
		this.editRow = this.editRow.bind(this);
		this.deleteRow = this.deleteRow.bind(this)
	}	

  onLogoutClick = e => {
    e.preventDefault();
    this.props.logoutUser();
  };
  getStudentData(id){
		const userInfo = localStorage.getItem("userinfo") ;
		if(userInfo){
		  var userRole = JSON.parse(userInfo);
		  let role = userRole.role == "student"  ? false : true;
		  if(!role){
			  return false
		  }else{
			console.log("course id",id);
			this.setState({innerRow :true})
			this.props.studentGetData(id);	  
		  }
		}
	 
  }
  componentDidMount() {
    if (this.props.auth.isAuthenticated) {
      this.props.history.push("/dashboard");
	  this.props.getAll();
	}
  }
  editRow(id){
	  console.log("edit id", id)
	  this.props.history.push(`/edit/${id}`);
  }
  deleteRow(id){
	  console.log("deleteRow id", id)
	  this.props.deleteData(id);
  }
  static getDerivedStateFromProps(nextProps, prevState) {
	  if (Object.values(nextProps.auth.courseinfo).length > 0) {
		return {students: nextProps.courseinfo};
	  }
	  return null;
  }
 
  render() {
	const userInfo = localStorage.getItem("userinfo") ;
    const { user ,courseinfo} = this.props.auth;
	if(userInfo){
		var userRole = JSON.parse(userInfo);
	}
	let tableData = [];
	this.state.students.forEach(student => {
		if(!this.state.innerRow && student.courseData.length > 0){
		student.courseData.forEach(table => {
				tableData.push({
				 Name:table.Name,_id:table._id,Description:table.Description ,
				 couseID:table.couseID,  start_date:table.start_date, end_date:table.end_date 
			 })
		 })	
		}	
	})
	
    return (
      <div style={{ height: "75vh" }} className="container valign-wrapper">
        <div className="row">
          <div className="landing-copy col s12 center-align">
            <h4>
              <b>Hey there,</b> {user.name}
            </h4>
			<div className="col-md-12">
			{ !this.state.innerRow && <table striped bordered hover variant="dark">
			  <thead>
				<tr>
				  <th>#</th>
				  <th>Course Name</th>
				  <th>Course Description</th>
				  <th>Start Date</th>
				  <th>End Date</th>
				  <th>Action</th>
				</tr>
			  </thead>
			  <tbody>
			  
			       {tableData.map((table, idx) => (
                    <tr id="addr0" key={table.couseID} onClick={this.getStudentData.bind(this,table.couseID)}>
                      <td>{idx}</td>
					   <td>{table.Name}</td>
					   <td>{table.Description}</td>
					   <td>{table.start_date}</td>
					   <td>{table.end_date}</td>
                      <td>
                        <Button
                          name="editRow"
                          value="Edit"
                          onClick={this.editRow.bind(this,table.couseID)}
                          variant="primary"
                        >Edit</Button>
                      </td>
					  <td>
                        <Button
                          name="deleteRow"
                          value="Delete"
                          onClick={this.deleteRow.bind(this,table.couseID)}
                          variant="secondary"
                        >Delete</Button>
                      </td>
                    </tr>
                  ))}			  
			  </tbody>
			</table>
			}
			/*{this.state.innerRow && 
			<table striped bordered hover variant="dark">
			  <thead>
				<tr>
				  <th>#</th>
				  <th>Studnet Name</th>
				  <th>Username</th>
				  <th>Join Date</th>
				</tr>
			  </thead>
			  <tbody>
			  
			       {this.state.students.map((stud, idx) => (
                    <tr key={stud.Id}>
                      <td>{idx}</td>
					   <td>{stud.first_name}{stud.last_name}</td>
					   <td>{stud.email}</td>
					   <td>{stud.joining_date}</td>
                    </tr>
                  ))}			  
			  </tbody>
			</table>
			}*/
			</div>
            <button
              style={{
                width: "150px",
                borderRadius: "3px",
                letterSpacing: "1.5px",
                marginTop: "1rem"
              }}
              onClick={this.onLogoutClick}
              className="btn btn-large waves-effect waves-light hoverable blue accent-3"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    );
  }
}

Dashboard.propTypes = {
  logoutUser: PropTypes.func.isRequired,
  getAll: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  courseinfo: PropTypes.object.isRequired,
  deleteData:PropTypes.func.isRequired,
  studentGetData : PropTypes.func.isRequired
  
};

const mapStateToProps = state => ({
  auth: state.auth,
  courseinfo : state.auth.courseinfo,
  studentData : state.auth.studentData
})

export default connect(
  mapStateToProps,
  { logoutUser , getAll ,studentGetData , deleteData }
)(Dashboard);
