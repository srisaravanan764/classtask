import axios from "axios";
import setAuthToken from "../utils/setAuthToken";
import jwt_decode from "jwt-decode";

import { GET_ERRORS, SET_CURRENT_USER, USER_LOADING,GET_ALL,DELETE_USER } from "./types";
let apiURL = "http://localhost:5000";

// Register User 
export const registerUser = (userData, history) => dispatch => {
	console.log("userData" ,userData)
  axios
    .post(apiURL +"/api/users/register", userData)
    .then(res => {
		localStorage.removeItem("couseID");
		history.push("/login")
	})
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};

// Login - get user token	
export const loginUser = userData => dispatch => {
  axios
    .post(apiURL+"/api/users/login", userData)
    .then(res => {
      const { token ,email,role} = res.data;
	  let userinfo = JSON.stringify({email :email, role:role});
	  console.log("userinfo",userinfo)
	  localStorage.setItem("userinfo",userinfo);
      localStorage.setItem("jwtToken", token);
      setAuthToken(token);
      const decoded = jwt_decode(token);
      dispatch(setCurrentUser(decoded));
    })
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err
      })
    );
};

// Set logged in user
export const setCurrentUser = decoded => {
  return {
    type: SET_CURRENT_USER,
    payload: decoded
  };
};

// User loading
export const setUserLoading = () => {
  return {
    type: USER_LOADING
  };
};

// Log user out
export const logoutUser = () => dispatch => {
  localStorage.removeItem("jwtToken");
  localStorage.removeItem("userinfo")
  setAuthToken(false);
  dispatch(setCurrentUser({}));
};

export const getAll = (id=null) => dispatch => { 
	let url = apiURL+"/api/users/get_all";
	if(id){
		url = `${url}/${id}`;
	}
	let userInfo = localStorage.getItem("userinfo") ? JSON.parse(localStorage.getItem("userinfo")):"";
	axios
    .post(url, {email : userInfo.email,role:userInfo.role})
    .then(res => {
		dispatch({
        type: GET_ALL,
        payload: res.data.data
      })
    })
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err
      })
    );
}
export const deleteData = (id)=> (dispatch) => {
let url = apiURL+"/api/users/";
	if(id){
		url = `${url}/${id}`;
	}
	axios
    .delete(url)
    .then(res => {
		dispatch({
        type: DELETE_USER,
        payload: res.data.data
      })
    })
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err
      })
    );
}
export const studentGetData = (id) => (dispatch) =>{
	let url = `${apiURL}/api/users/${id}`;
	axios
    .get(url)
    .then(res => {
		dispatch({
        type: GET_ALL,
        payload: res.data.data
      })
    })
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err
      })
    );
}